//
// Created by part4 on 28.01.2022.
//

#ifndef GRAFIKA_SHADER_H
#define GRAFIKA_SHADER_H

#include <GL/glew.h>

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

class Shader {
    public:
        // the program ID
        unsigned int ID{};
        Shader();
        // constructor reads and builds the shader
        Shader(const char* vertexPath, const char* fragmentPath);
        // activate/deactivate the shader
        void activate() const;
        void deactivate() const;
        // utility uniform functions
        void setBool(const string &name, bool value) const;
        void setInt(const string &name, int value) const;
        void setFloat(const string &name, float value) const;
};


#endif //GRAFIKA_SHADER_H
